package com.urbank.loanservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
